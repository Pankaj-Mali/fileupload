const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors")
const user = require("./model/user")

const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const secrete = "pankaj@secrete"


const app = express();
mongoose.connect("mongodb://0.0.0.0/authentication", (e) => {
    if (e) { console.log(e.message) } else { console.log("mongoose is up ") }
})

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));


app.post("/resister", async (req, res) => {

    try {
        let pass = req.body.pass
        pass = await bcrypt.hash(pass, 10);
        req.body.pass = pass;
        const data = await user.create(req.body);
        res.status(200).json({
           message:"resistration  complited"
        })
    } catch (e) {

        res.status(400).json({
            status: "Failed",
            message: e.message
        })

    }
})

app.post("/login", async (req, res) => {

    try {
        
        const email = req.body.email
        const user_data = await user.findOne({ email: email });
        if (user_data != null) {
            const input = await bcrypt.compare(req.body.pass, user_data.pass);
            if (input) {
                const tocken = jwt.sign({
                    exp: Math.floor(Date.now() / 100) + (60 * 60),
                    data: user_data._id
                }, secrete)

                res.status(200).json({
                    message: tocken
                })
            } else {
                res.status(401).json({
                    message: "Wrong password"
                })

            }
        } else {
            res.status(401).json({
                message: "user not resistered"
            })
        }


    } catch (e) {

        res.status(400).json({
            status: "Failed",
            message: e.message
        })

    }
})


app.get("/home", async (req, res) => {

    try {
        const token = req.headers.authorization;
        const verify= jwt.verify(token, secrete);
        const decoded = jwt.decode(token)
        
       if(verify){
        res.status(200).json({
           message:"user is authenticated"
           })
       }else{
        res.status(400).json({
            message:"user is Not authenticated"
            })
       }
       
    } catch (e) {

        res.status(400).json({
            status: "Failed",
            message: e.message
        })

    }
})

app.listen(8080, (e) => {
    if (e) { console.log(e.message) } else { console.log("server is up at 3000") }
})