import Register from "./components/register";
import {Route, Routes, BrowserRouter} from "react-router-dom"
import Login from './components/login';
import {useState} from "react"
import Home from "./components/home";



function App() {
  const [tocken , setTocken]=useState("")
  const [member , setMember]=useState("")
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/register' element={ <Register/>} />
      <Route path='/'element={<Login tocken={tocken} setTocken={setTocken} member={member} setMember={setMember}/>} ></Route>
      <Route path='/home'element={<Home tocken={tocken} setTocken={setTocken} member={member} setMember={setMember}/>} ></Route>
    </Routes>
    </BrowserRouter>
    
   
  );
}

export default App;
