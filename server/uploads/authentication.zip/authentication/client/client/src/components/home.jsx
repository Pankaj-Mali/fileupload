import React from 'react'
import { useNavigate } from "react-router-dom"
import {useEffect , useState} from "react"

function Home(props) {
    const {member,tocken,setTocken}=props;
    console.log(tocken);
    const nav= useNavigate()
    const [data,SetData]=useState([])
    useEffect(()=>{
        fetch("http://localhost:8080/home",{
            method:"GET",
            headers:{
              "Accept":"application/json",
              "Content-Type":"application/json",
              "Authorization":tocken
            }
          }).then(x=>x.json()).then(data=>{
            console.log(data)

           SetData(data.message)
            })
    },[tocken,[]]);
    const handleLogout=()=>{

      setTocken("");
      nav("/")
    }
  return (
    <div className='main'>
        <div className='header'>
            <span className='member'>{member}</span>
        </div>

        <div className='logout-table-holder'>
            <div className='lout-div-holder'>
              <div className='text'>
                <p>
                 {data}
                </p>
              </div>
              <div className='log'>
                <p onClick={handleLogout}>
                  LOGOUT
                </p>
              </div>

            </div>
            
            <div className='table-holder'>

            </div>
        </div>
    </div>
  )
}

export default Home