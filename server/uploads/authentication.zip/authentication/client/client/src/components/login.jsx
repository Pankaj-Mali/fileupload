import React from 'react'
import { useState } from 'react'
import { useNavigate } from "react-router-dom"
import ("../style/login.css")

function Login(props) {

    const{tocken, setTocken, member, setMember} = props

    const [form, setForm] = useState({});
    const [email, setEmail] = useState("")
    const [pass, setPass] = useState("");
    const [message ,setMessage] = useState("")
    let nav = useNavigate()

    const handleemail = (e) => {
        let email=e.target.value;
        setEmail(email)
        setMember(email)
    }
    const handdlepass = (e) => {
        const pass = e.target.value
        let oj = {
            email: email,
            pass: pass
        }
        setForm(oj)
        setPass(pass)
    }

    const entry = (e) => {
        e.preventDefault();
            fetch("http://localhost:8080/login", {
                method: "POST",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(form)
            }).then((data) => data.json())
                .then((response) => {setTocken(response.message);
                    setMessage(response.message)
                    console.log(message)
                });
               if(message==="Wrong password")
               {
                alert(message)
               }else if(message==="user not resistered"){
                alert(message)
                }else if(message){
                 nav("/home")
                }
    }
    const fun =()=>{
        nav("/register")
    }

    return (
        <div className='form-holder2'>
            <div className='form2'>
                <p>LOGIN MEMBER</p>
                <form action="/resister">
                    <div className='email'>
                        <input className='input'
                            onChange={handleemail}
                            name='email'
                            type="email"
                            placeholder="email"
                            value={email}
                            required
                            ></input>
                    </div>
                    <div className='pass'>
                        <input
                            className='input'
                            onChange={handdlepass}
                            name='pass'
                            type="text"
                            placeholder="passWord"
                            value={pass}
                            required
                            ></input>
                    </div>
                    <button className='button' onClick={entry}>login</button>
                    <p onClick={fun} className='nav2'>I Am Not A MEMBER</p>
                </form>
            </div>
        </div>

    )
}

export default Login